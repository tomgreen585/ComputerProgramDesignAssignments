// This program is copyright VUW.
// You are granted permission to use it to construct your answer to a COMP102/112 assignment.
// You may not distribute it in any other way without permission.

/* Code for COMP-102-112 - 2022T1, Assignment 3
 * Name:
 * Username:
 * ID:
 */

import ecs100.*;
import java.awt.Color;
import javax.swing.JColorChooser;

/** Parameterised Shapes: 
 * Core and Completion: draw flags with three horizontal stripes
 * Challenge: draw a street of houses
 */
public class ParameterisedShapes{

    //Constants for CORE and COMPLETION  (three stripes flags)
    public static final double FLAG_WIDTH = 200;
    public static final double FLAG_HEIGHT = 133;

    /**   CORE
     * Asks user for a position and three colours, then calls the
     * drawThreeStripesFlag method, passing the appropriate arguments
     */
    public void doSimpleFlag(){
        double left = UI.askDouble("Left of flag");
        double top = UI.askDouble("Top of flag");
        UI.println("Now choose the colours");
        Color stripe1 = JColorChooser.showDialog(null, "First Stripe", Color.white);
        Color stripe2 = JColorChooser.showDialog(null, "Second Stripe", Color.white);
        Color stripe3 = JColorChooser.showDialog(null, "Third Stripe", Color.white);
        this.drawThreeStripesFlag(/*# YOUR CODE HERE */ );
    }

    /**   CORE
     * Draws a three colour flag at the given position consisting of
     * three equal size stripes of the given colors
     * The stripes are horizontal.
     * The size of the flag is specified by the constants FLAG_WIDTH and FLAG_HEIGHT
     */
    public void drawThreeStripesFlag(/*# YOUR CODE HERE */ ){
        UI.clearGraphics();
        /*# YOUR CODE HERE */

    }

    /**   COMPLETION
     * Asks user for a position, three colours, three heights and whether the circles are filled.
     * Then calls the drawFancyFlag method, passing the appropriate arguments
     */
    public void doFancyFlag(){
        double left = UI.askDouble("Left of flag");
        double top = UI.askDouble("Top of flag");
        UI.println("Now choose the colours");
        Color col1 = JColorChooser.showDialog(null, "First Stripe", Color.white);
        Color col2 = JColorChooser.showDialog(null, "Second Stripe", Color.white);
        Color col3 = JColorChooser.showDialog(null, "Third Stripe", Color.white);
        UI.println("Now choose the sizes");
        /*# YOUR CODE HERE */

    }

    /**   COMPLETION
     * Calculates the total height and width of the flag.
     * The width of the flag is 1.5 times the height of the flag.
     * It then calls drawStripe three times to draw the three stripes,
     * and outlines the flag with a black rectangle.
     */
    public void drawFancyFlag(/*# YOUR CODE HERE */ ){
        UI.clearGraphics();
        /*# YOUR CODE HERE */

    }

    /**   COMPLETION
     * Draws a stripe at the given position that has the right circle at the right place.
     */
    public void drawStripe(/*# YOUR CODE HERE */ ){
        /*# YOUR CODE HERE */

    }

    public void setupGUI(){
        UI.initialise();
        UI.addButton("Clear", UI::clearPanes );
        UI.addButton("Simple Flag", this::doSimpleFlag );
        UI.addButton("Fancy Flag", this::doFancyFlag );
        // Add a button here to call your method for the challenge part
        UI.addButton("Quit", UI::quit );
    }

    public static void main(String[] args){
        ParameterisedShapes ps = new ParameterisedShapes ();
        ps.setupGUI();
    }

}
